#!/usr/bin/env python3

from .Gaussiandistribution import Gaussian
from .Generaldistribution import Distribution

# Use the Gaussian and Distribution classes as needed
