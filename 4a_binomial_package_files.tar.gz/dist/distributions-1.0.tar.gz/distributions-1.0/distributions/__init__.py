#!/usr/bin/env python3

from .Gaussiandistribution import Gaussian
from .Generaldistribution import Distribution
from .Binomialdistribution import Binomial

# import the Binomial class from the Binomialdistribution module
# Use the Gaussian, Distribution, and Binomial classes as needed
